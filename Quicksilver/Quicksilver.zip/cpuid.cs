﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Quicksilver2013
{
    class cpuid
    {
        public static Cosmos.Hardware.SMBIOS.Table.ProcessorInformation pi;
    }
}
